package com.sistema.login;

import com.sistema.login.view.LoginView;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Crear y mostrar la ventana de Login
            LoginView loginView = new LoginView();
            loginView.show(primaryStage);

        } catch (Exception e) {
            System.err.println("Error al iniciar la aplicación: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // launch() inicia la aplicación JavaFX y llama a start()
        launch(args);
    }
}